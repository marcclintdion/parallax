  var     eyePosition[] = {-2.8, 1.95, 8.70001, 1};
  var     look_LEFT_RIGHT           =  0;
  var     look_UP_DOWN         =  0;
