  GLfloat     facing_UP_LIGHT_POSITION_01[] = {40.31, 55.1199, 40, 1};
  GLfloat     facing_UP_ATTENUATION         =  -0.025;
  GLfloat     facing_UP_SHININESS           =  0.0439999;
