GLfloat     facing_VIEW_POSITION[]            =  {  0.0, 0.0, 0.0, 1.0};     
GLfloat     facing_VIEW_ROTATE[]              =  {  0.0, 1.0,  0.0, 0.0};    
GLfloat     facing_VIEW_SCALE[]               =  {  1.0, 1.0,  1.0, 1.0};    
//-----------------------------------------------------------------                     
GLfloat     facing_VIEW_LIGHT_POSITION_01[]   =  {  2.0, 15.0, -30.0, 1.0};   
GLfloat     facing_VIEW_SHININESS             =    80.0;                     
GLfloat     facing_VIEW_ATTENUATION           =     1.0;                     
//-----------------------------------------------------------------                     
GLuint      facing_VIEW_VBO;                                                 
GLuint      facing_VIEW_INDICES_VBO;                                         
//-----------------------------------------------------------------                     
GLuint      facing_VIEW_HEIGHT;  
GLuint      facing_VIEW_NORMALMAP;                                           
GLuint      facing_VIEW_TEXTUREMAP;                                          
