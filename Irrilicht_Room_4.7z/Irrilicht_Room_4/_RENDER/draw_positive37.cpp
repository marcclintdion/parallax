
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   8.0;
tile_2m_POSITION[2] =  -0.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   8.0;
tile_2m_POSITION[2] =  -2.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   8.0;
tile_2m_POSITION[2] =  -4.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   8.0;
tile_2m_POSITION[2] =  -6.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//------------------------------------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   6.0;
tile_2m_POSITION[2] =  -0.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   6.0;
tile_2m_POSITION[2] =  -2.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   6.0;
tile_2m_POSITION[2] =  -4.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   6.0;
tile_2m_POSITION[2] =  -6.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//------------------------------------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   4.0;
tile_2m_POSITION[2] =  -0.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   4.0;
tile_2m_POSITION[2] =  -2.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   4.0;
tile_2m_POSITION[2] =  -4.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------
tile_2m_POSITION[0] =  37.0;
tile_2m_POSITION[1] =   4.0;
tile_2m_POSITION[2] =  -6.0;
//--------------------------
tile_2m_ROTATE[0]   =   0.0; 
tile_2m_ROTATE[1]   =   0.0; 
tile_2m_ROTATE[2]   =   1.0; 
tile_2m_ROTATE[3]   = -90.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
