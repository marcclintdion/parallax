
//============================================================================================================
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    -1.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    1.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    3.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    5.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    7.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    9.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------

tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    11.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    13.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   -6.0;
tile_2m_POSITION[1] =    15.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------






