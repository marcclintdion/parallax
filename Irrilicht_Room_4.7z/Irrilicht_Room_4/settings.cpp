var         facing_UP_LIGHT_POSITION_01[]            =  {14.11, 10.6199, 22.4007, 1.0};

var         facing_UP_ATTENUATION            =  -0.0143;
var         facing_UP_SHININESS              =  0.0625005;


//------------------------------------------------------------------------------ 
        var         moveSet[]                  =  {-0.4, -0.54, -5.89998, 1.0};
        var         rotateModelWithLeftMouse[] =  {7.19998, -0.299973, 0.0, 0.0};

